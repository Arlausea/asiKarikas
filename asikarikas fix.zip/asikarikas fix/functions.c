#include "header.h"

void highlight(int x, int y, int shift_x, int shift_y, int window_w, int window_h, int zoom, SDL_Renderer *renderer){
    int size = 64;
    SDL_Rect rect;
    rect.w = size;
    rect.h = size;

    rect.y = shift_y-(window_h*zoom-window_h)/2 + y*zoom - size/2;
    rect.x = shift_x-(window_w*zoom-window_w)/2 + x*zoom - size/2;
    
    SDL_RenderDrawRect(renderer, &rect); // Draw.
    SDL_RenderFillRect(renderer, &rect);
}


// Names and short names might be wrong.
void get_x_y(char name[], int *x, int *y){
    if(!strcmp(name, "library") || !strcmp(name, "lib")){
        *x = 658;
        *y = 638;
        return;
    }
    else if(!strcmp(name, "study building 1") || !strcmp(name, "u01"))
    {
        *x = 549;
        *y = 593;
        return;
    }
    else if(!strcmp(name, "study building 2") || !strcmp(name, "u02"))
    {
        *x = 519;
        *y = 565;
        return;
    }
    else if(!strcmp(name, "study building 3") || !strcmp(name, "u03"))
    {
        *x = 534;
        *y = 542;
        return;
    }

    else if(!strcmp(name, "study building 4") || !strcmp(name, "u04"))
    {
        *x = 549;
        *y = 512;
        return;
    }
     else if(!strcmp(name, "study building 5") || !strcmp(name, "u05"))
    {
        *x = 563;
        *y = 488;
        return;
    }
    else if(!strcmp(name, "study building 6") || !strcmp(name, "u06"))
    {
        *x = 575;
        *y = 463;
        return;
    }
    else if(!strcmp(name, "study building 7") || !strcmp(name, "nrg"))
    {
        *x = 613;
        *y = 613;
        return;
    }
    else if(!strcmp(name, "building of natural science") || !strcmp(name, "sci"))
    {
        *x = 878;
        *y = 416;
        return;
    }
    else if(!strcmp(name, "student hostel 1") || !strcmp(name, "do1"))
    {
        *x = 668;
        *y = 547;
        return;
    }
    else if(!strcmp(name, "student hostel 2") || !strcmp(name, "do2"))
    {
        *x = 696;
        *y = 493;
        return;
    }
    else if(!strcmp(name, "student hostel 3") || !strcmp(name, "do3"))
    {
        *x = 723;
        *y = 440;
        return;
    }
    else if(!strcmp(name, "family hostel") || !strcmp(name, "do4"))
    {
        *x = 737;
        *y = 494;
        return;
    }
    else if(!strcmp(name, "academic hostel") || !strcmp(name, "ho1")) //note.
    {
        *x = 783;
        *y = 453;
        return;
    }
    else if(!strcmp(name, "student hostel") || !strcmp(name, "do7"))
    {
        *x = 810;
        *y = 444;
        return;
    }
    else if(!strcmp(name, "it building") || !strcmp(name, "do6"))
    {
        *x = 776;
        *y = 270;
        return;
    }
    else if(!strcmp(name, "laboratory building of civil engineering") || !strcmp(name, "mek"))
    {
        *x = 851;
        *y = 216;
        return;
    }
    else if(!strcmp(name, "technology park") || !strcmp(name, "con"))
    {
        *x = 967;
        *y = 325;
        return;
    }
    else if(!strcmp(name, "building of cybernetics") || !strcmp(name, "ico"))
    {
        *x = 921;
        *y = 443;
        return;
    }
    else if(!strcmp(name, "building of woodworking ") || !strcmp(name, "ict"))
    {
        *x = 1074;
        *y = 343;
        return;
    }
    else if(!strcmp(name, "stadium") || !strcmp(name, "cyb"))
    {
        *x = 628;
        *y = 330;
        return;
    }
    else if(!strcmp(name, "textile technology building") || !strcmp(name, "tim"))
    {
        *x = 233;
        *y = 633;
        return;
    }
    else if(!strcmp(name, "sports centre") || !strcmp(name, "sta"))
    {
        *x = 299;
        *y = 683;
        return;
    }
    else if(!strcmp(name, "study building 10"))
    {
        *x = 668;
        *y = 608;
        return;
    }
    else if(!strcmp(name, "") || !strcmp(name, "s01"))
    {
        *x = 111;
        *y = 111;
        return;
    }
    else if(!strcmp(name, "") || !strcmp(name, "soc"))
    {
        *x = 658;
        *y = 634;
        return;
    }
    else if(!strcmp(name, "student house") || !strcmp(name, "stu"))
    {
        *x = 585;
        *y = 566;
        return;
    }
}