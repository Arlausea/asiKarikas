#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include"SDL2/SDL.h"

// Visual functions.
void highlight(int, int, int, int, int, int, int, SDL_Renderer *);

// info functions.
void get_x_y(char name[], int *x, int *y);