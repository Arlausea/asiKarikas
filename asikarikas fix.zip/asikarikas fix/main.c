#include "functions.c"


// ToDo:

/*
SDL credits in SDL_IMPORTANT_NOTES > CREDITS
(SDL is amazing! Many thanks to the developers of SDL!)

Compile command:
gcc -Isrc/Include -Lsrc/lib -o run main.c -lmingw32 -lSDL2main -lSDL2

*/

int main(int argc, char* args[])
{
    FILE* f1 = fopen("data\\name.txt","r");
    FILE* f2 = fopen("data\\codename.txt","r");

    printf("Enter input string \n");
    char inputname [30];
    //char inputcode[5];

    scanf("%s",inputname);
    //printf("Please enter code\n");
    //scanf("%s",inputcode);
    char name[30];
    char code[5];
    int index = 0;
    while (fscanf(f1,"%s",name) != EOF){

        for (int i = 0; i <strlen(name);i++){
            if (name[i] == inputname[0]){
                for (int j = 0;j < strlen(inputname);j++){
                    if (name[i+j] == inputname[j]){
                        index++;
                    }
                }
                if (index == strlen(inputname)){
                    printf("%s\n",name);
                    index = 0;
                    break;
                }
                else{
                    index = 0;
                    break;
                }
                
            }
        }
    }
     while (fscanf(f2,"%s",code) != EOF){

        for (int i = 0; i <strlen(code);i++){
            if (code[i] == inputname[0]){
                for (int j = 0;j < strlen(inputname);j++){
                    if (code[i+j] == inputname[j]){
                        index++;
                    }
                }
                if (index == strlen(inputname)){
                    printf("%s\n",code);
                    index = 0;
                    break;
                }
                else{
                    index = 0;
                    break;
                }
                
            }
        }
    }

    printf("Please enter 1 of the previous correctly. \n"); // Just a quick fix.
    scanf("%s",inputname);

    int place_pos_x = 0;
    int place_pos_y = 0;
    get_x_y(inputname, &place_pos_x, &place_pos_y);

    /*-----------\
    | Rendering. |
    \-----------*/

    int running = 1;
    int window_height = 840; // 480;
    int window_with = 1120; // 640

    int zoom = 1;

    // Mouse position.
    int mouse_x;
    int mouse_y;
    int mouse_x_old;
    int mouse_y_old;
    int right_clicking = 0;
    SDL_GetMouseState(&mouse_x_old, &mouse_y_old);

    int shift_x = 0;
    int shift_y = 0;

    // Set up SDL.
    SDL_Window *window = NULL;
    SDL_Renderer *renderer = NULL;
    SDL_Event event;

    SDL_Surface *surface;

    SDL_Init(SDL_INIT_EVERYTHING);
    SDL_CreateWindowAndRenderer(window_with, window_height, 0, &window, &renderer);
    SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND); // Enables alpha blending.

    // SDL_SetWindowResizable(window, SDL_TRUE);

    // Texture
    surface = SDL_LoadBMP("textures\\map.bmp");
    SDL_Texture* texture_map = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_Rect rect;
    rect.w = window_with;
    rect.h = window_height;
    rect.y = 0;
    rect.x = 0;

    // Main loop.
    while(running){
        while(SDL_PollEvent(&event)){
            switch(event.type){
            case SDL_QUIT:
                running = 0;
                break;
            case SDL_MOUSEWHEEL:
                if(event.wheel.y > 0){
                    if(zoom<6){
                        zoom++;
                    }
                }
                else if(event.wheel.y < 0){
                    if(zoom>1){
                        zoom--;
                    }
                }
                break;
            case SDL_MOUSEBUTTONUP:
                switch(event.button.button){
                case SDL_BUTTON_RIGHT:
                    right_clicking = 0;
                    break;
                default:
                    break;
                }
                break;
            case SDL_MOUSEBUTTONDOWN:
                switch(event.button.button){
                case SDL_BUTTON_RIGHT:
                    right_clicking = 1;
                    break;
                case SDL_BUTTON_LEFT:
                    SDL_GetMouseState(&mouse_x, &mouse_y); // Works only for zoom = 1! For development use!
                    if(zoom == 1){
                        printf("Mouse pos:\n\t*x = %d;\n\t*y = %d;\n\treturn;\n\n", mouse_x-shift_x, mouse_y-shift_y);
                    }
                    zoom = 1;
                    break;
                default:
                    break;
                }
                break;
            case SDL_KEYDOWN:
                switch(event.key.keysym.sym){
                case SDLK_ESCAPE:
                    running = 0;
                    break;
                default: // Without this case,the previous case was considered as default.
                    break;
                }
            }
        }

        // Logic.
        if(right_clicking){
            SDL_GetMouseState(&mouse_x, &mouse_y);
            shift_x = (shift_x + mouse_x - mouse_x_old);
            shift_y = (shift_y + mouse_y - mouse_y_old);

            SDL_GetMouseState(&mouse_x_old, &mouse_y_old);
        }
        else{
            SDL_GetMouseState(&mouse_x_old, &mouse_y_old);
        }

        rect.y = shift_y-(window_height*zoom-window_height)/2;
        rect.x = shift_x-(window_with*zoom-window_with)/2;
        rect.w = window_with * zoom;
        rect.h = window_height * zoom;

        // Rendering.
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);

        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255); // Give rect a color.

        SDL_RenderDrawRect(renderer, &rect); // Draw.

        SDL_RenderCopy(renderer, texture_map, NULL, &rect); // 1st NULL can be replaced to say what part to copy, NULL says that copy all.

        SDL_SetRenderDrawColor(renderer, 130, 130, 10, 100); // Give rect a color.
        highlight(place_pos_x, place_pos_y, shift_x, shift_y, window_with, window_height, zoom, renderer);

        SDL_RenderPresent(renderer); // Update window.
    }

    // Start exiting.
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    // Free textures:
    SDL_FreeSurface(surface);

    SDL_DestroyTexture(texture_map);

    return 0;
}